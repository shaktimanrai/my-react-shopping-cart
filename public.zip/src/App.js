import React from 'react'
import './App.css'
import Header from './components/Header';
import Test from './components/Test'



 function App() {
  return (<>
  <Header />
  <Test/>
<Test/>
<Test/>
<Test/>
<Test/>
<Test/>

    </>
  )
}
export default App;